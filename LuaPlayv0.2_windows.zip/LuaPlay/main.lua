window.Create(800, 600, "Title")

-- Called after window.Create to get the 'real' size.
screenW = window.GetSize().w;
screenH = window.GetSize().h;

hook.Add("Render", function()
	graphics.DrawRect(75, 451, 82, 43)
	graphics.DrawTriangle(Vector(2, 41), Vector(42, 43), Vector(20, 10), Color(255, 0, 0))
	graphics.DrawCircle(500, 300, 50, Color(255, 0, 0), false, 23)
end)

hook.Add("Update", function()
	if(input.KeyDown(KEY_W))then
		print("Pressed W!")
	end
end)